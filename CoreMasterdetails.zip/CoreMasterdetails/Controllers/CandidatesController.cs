﻿using CoreMasterdetails.Models;
using CoreMasterdetails.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace CoreMasterdetails.Controllers
{
    public class CandidatesController : Controller
    {
        public IWebHostEnvironment _he;
        public CandidateDbContext _context;
        public CandidatesController(IWebHostEnvironment _he, CandidateDbContext _context)
        {
            this._he = _he;
            this._context = _context;
        }

        public async Task<IActionResult> Index()
        {
            return View(await _context.Candidates.Include(x=>x.CandidateSubjects).ThenInclude(y=>y.Subject).ToListAsync());
        }

        public IActionResult Create()
        {
            return View();
        }

        public IActionResult AddNewSubject(int ? id)
        {
            ViewBag.subject = new SelectList(_context.Subjects, "SubjectId", "SubjectName", id.ToString() ?? "");
            return PartialView("_AddNewSubject");
        }
        [HttpPost]
        public async Task <IActionResult> Create(CandidateVM candidateVM, int[] SubjectId)
        {
            if(ModelState.IsValid)
            {
                Candidate candidate = new Candidate()
                {
                    CandidateName = candidateVM.CandidateName,
                    DateOfBirth = candidateVM.DateOfBirth,
                    Phone = candidateVM.Phone,
                    Fresher = candidateVM.Fresher
                };

                var file=candidateVM.ImagePath;
                string webrrot = _he.WebRootPath;
                string folder = "Images";
                string imgFileName=DateTime.Now.Ticks.ToString()+"_"+Path.GetFileName(candidateVM.ImagePath.FileName);
                string filetoSave=Path.Combine(webrrot, folder,imgFileName);
                if(file != null)
                {
                    using (var stream = new FileStream(filetoSave, FileMode.Create))
                    {
                        candidateVM.ImagePath.CopyTo(stream);
                        candidate.Image = "/" + folder + "/" + imgFileName;
                    }

                }
                foreach (var item in SubjectId)
                {
                    CandidateSubject candidateSubject = new CandidateSubject
                    {
                        Candidate = candidate,
                        CandidateId = candidate.CandidateId,
                        SubjectId = item
                    };
                    _context.CandidatesSubjects.Add(candidateSubject);
                }
                await _context.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View();
        }

        public async Task<IActionResult> Edit(int? id)
        {
            var candidate = await _context.Candidates.FirstOrDefaultAsync(x => x.CandidateId == id);

            CandidateVM candidateVM = new CandidateVM()
            {
                CandidateId = candidate.CandidateId,
                CandidateName = candidate.CandidateName,
                DateOfBirth = candidate.DateOfBirth,
                Phone = candidate.Phone,
                Image = candidate.Image,
                Fresher = candidate.Fresher
            };
            var existSkill = _context.CandidatesSubjects.Where(x => x.CandidateId == id).ToList();
            foreach (var item in existSkill)
            {
                candidateVM.Subjectlists.Add(item.SubjectId);
            }
            return View(candidateVM);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(CandidateVM candidateVM, int[] SkillId)
        {
            if (ModelState.IsValid)
            {
                Candidate candidate = new Candidate()
                {
                    CandidateId = candidateVM.CandidateId,
                    CandidateName = candidateVM.CandidateName,
                    DateOfBirth = candidateVM.DateOfBirth,
                    Phone = candidateVM.Phone,
                    Fresher = candidateVM.Fresher,
                    Image = candidateVM.Image
                };
                var file = candidateVM.ImagePath;
                string existImg = candidateVM.Image;

                if (file != null)
                {
                    string webroot = _he.WebRootPath;
                    string folder = "Images";
                    string imgFileName = DateTime.Now.Ticks.ToString() + "_" + Path.GetFileName(candidateVM.ImagePath.FileName);
                    string fileToSave = Path.Combine(webroot, folder, imgFileName);
                    using (var stream = new FileStream(fileToSave, FileMode.Create))
                    {
                        candidateVM.ImagePath.CopyTo(stream);
                        candidate.Image = "/" + folder + "/" + imgFileName;
                    }

                }
                else
                {
                    candidate.Image = existImg;
                }

                var existSkill = _context.CandidatesSubjects.Where(x => x.CandidateId == candidate.CandidateId).ToList();
                //Remove
                foreach (var item in existSkill)
                {
                    _context.CandidatesSubjects.Remove(item);
                }
                //Add
                foreach (var item in SkillId)
                {
                    CandidateSubject candidateSubject = new CandidateSubject()
                    {
                        CandidateId = candidate.CandidateId,
                        SubjectId = item
                    };
                    _context.CandidatesSubjects.Add(candidateSubject);
                }
                _context.Update(candidate);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View();
        }

        public async Task<IActionResult> Delete(int? id)
        {
            var candidate = await _context.Candidates.FirstOrDefaultAsync(x => x.CandidateId == id);
            var existSkill = _context.CandidatesSubjects.Where(x => x.CandidateId == id).ToList();
            foreach (var item in existSkill)
            {
                _context.CandidatesSubjects.Remove(item);
            }

            _context.Remove(candidate);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}

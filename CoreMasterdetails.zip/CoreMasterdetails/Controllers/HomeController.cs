using CoreMasterdetails.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace CoreMasterdetails.Controllers
{
    public class HomeController : Controller
    {
       

        private CandidateDbContext _context;
        public HomeController(CandidateDbContext context)
        {
            this._context = context;
        }
      

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Result()
        {
            int totalSubject= _context.Results.Where(x=>x.CandidateId ==1).Count();
            ViewBag.TotalSubject = totalSubject;

            int totalNumber =(int) _context.Results.Where(x => x.CandidateId == 1).Sum(x=>x.Marks);
            ViewBag.totalNumber = totalNumber;

            int MaxNumber =(int) _context.Results.Where(x => x.CandidateId == 1).Max(x => x.Marks);
            ViewBag.MaxNumber = MaxNumber;

            int MinNumber = (int)_context.Results.Where(x => x.CandidateId == 1).Min(x => x.Marks);
            ViewBag.MinNumber = MinNumber;

            int AverageNumber = (int)_context.Results.Where(x => x.CandidateId == 1).Average(x => x.Marks);
            ViewBag.AverageNumber = AverageNumber;
            return View();
        }

       
    }
}

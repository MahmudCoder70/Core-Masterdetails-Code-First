﻿using Microsoft.EntityFrameworkCore;

namespace CoreMasterdetails.Models
{
    public class CandidateDbContext:DbContext
    {
        public CandidateDbContext (DbContextOptions<CandidateDbContext> options) : base(options) 
        { 
        
        }
        public DbSet<Candidate> Candidates { get; set;}
        public DbSet<Subject> Subjects { get; set;}
        public DbSet<Result> Results { get; set;}
        public DbSet<CandidateSubject> CandidatesSubjects { get; set;}
    }
}

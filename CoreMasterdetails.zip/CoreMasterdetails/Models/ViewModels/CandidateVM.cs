﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace CoreMasterdetails.Models.ViewModels
{
    public class CandidateVM
    {
        public int CandidateId { get; set; }
        [Required, Display(Name = "Candidate Name")]
        public string CandidateName { get; set; } = default!;
        [Required, Display(Name = "Date Of Birth"), Column(TypeName = "date")]
        public DateTime DateOfBirth { get; set; }
        public string Phone { get; set; } = default!;
        public string? Image { get; set; }
        [Display(Name ="Image")]
        public IFormFile? ImagePath { get; set; }
        [Display(Name ="Status")]
        public bool Fresher { get; set; }

        public List<int> Subjectlists { get; set; }= new List<int>();
    }
}

﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoreMasterdetails.Models
{
    public class Candidate
    {
        public int CandidateId { get; set; }
        [Required,Display(Name = "Candidate Name")]
        public string CandidateName { get; set; } = default!;
        [Required, Display(Name = "Date Of Birth"),Column(TypeName ="date")]
        public DateTime DateOfBirth { get; set; }
        public string Phone { get; set; } = default!;
        public string? Image { get; set; }
        public bool Fresher { get; set; }
        public ICollection<CandidateSubject> CandidateSubjects { get; set; } = new List<CandidateSubject>();
        public ICollection<Result> Results { get; set; } = new List<Result>();
    }
}
